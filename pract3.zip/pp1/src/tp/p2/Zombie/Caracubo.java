package tp.p2.Zombie;

public class Caracubo extends Zombie{
	
	static final int SPEED = 4;
	static final int STRENGHT = 8;
	static final char CHAR = 'W';
	static final String DEF = "Zombie caracubo";
	
	public Caracubo(){
		super(0, 0, STRENGHT, SPEED,CHAR,DEF);
	}



}
