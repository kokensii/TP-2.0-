package tp.p2.Printer;

public interface GamePrinter {
	
	public String printGame(); 
}
