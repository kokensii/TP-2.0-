package tp.p2.Exceptions;

public class CommandExecuteException extends Exception{
	
	public CommandExecuteException(String msg){
		super(msg);
	}
}
