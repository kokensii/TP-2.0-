package tp.p2.Exceptions;

public class CommandParseException extends Exception{
	
	public CommandParseException(String msg){
		super(msg);
	}
}
