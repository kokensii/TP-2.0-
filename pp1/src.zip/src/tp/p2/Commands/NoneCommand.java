package tp.p2.Commands;

import tp.p2.Controller.Controller;
import tp.p2.Game.Game;

public class NoneCommand extends NoParamsCommand{

	public NoneCommand() {
		super("none", "", "skips cycle");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute(Game game, Controller controller) {
		// TODO Auto-generated method stub
			game.update();
	} 
}
