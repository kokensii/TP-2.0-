package tp.p2.Commands;

import tp.p2.Controller.Controller;
import tp.p2.Game.Game;

public class ExitCommand extends NoParamsCommand{

	public ExitCommand() {
		super("exit", "E", "[E]xit: terminate the program.");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute(Game game, Controller controller) {
		// TODO Auto-generated method stub
		game.exit(); //Implementar en game
		controller.setNoPrintGameState();
	}
}
