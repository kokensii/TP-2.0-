package tp.p2.Commands;

import tp.p2.Controller.Controller;
import tp.p2.Game.Game;

public abstract class Command {

	private String helpText;
	private String helpInfo;
	protected final String commandName;
	
	public Command(String commandText, String commandTextMsg, String helpTextMsg){
		commandName = commandText;
		helpText = commandTextMsg;
		helpInfo = helpTextMsg;
	}
	
	public abstract void execute(Game game, Controller controller);
	public abstract Command parse(String[] commandWords, Controller controller);
	
	public String helpText(){return " " + helpText + ": " + helpInfo;}
}
