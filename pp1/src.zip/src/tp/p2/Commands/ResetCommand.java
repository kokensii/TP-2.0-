package tp.p2.Commands;

import tp.p2.Controller.Controller;
import tp.p2.Game.Game;

public class ResetCommand extends NoParamsCommand{

	public ResetCommand() {
		super("reset", "R", "[R]eset: resets games.");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute(Game game, Controller controller) {
		// TODO Auto-generated method stub
		game.resetGame();
		
	}

}
