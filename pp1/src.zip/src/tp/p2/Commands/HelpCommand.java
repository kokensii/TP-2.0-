package tp.p2.Commands;

import tp.p2.Controller.Controller;
import tp.p2.Game.Game;

public class HelpCommand extends NoParamsCommand{

	public HelpCommand() {
		super("help", "H", "[H]elp: print this help message.");
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void execute(Game game, Controller controller) {
		// TODO Auto-generated method stub
		System.out.println(CommandParser.commandHelp());
		controller.setNoPrintGameState();
	}

}

	
