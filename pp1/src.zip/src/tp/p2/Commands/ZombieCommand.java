package tp.p2.Commands;

import tp.p2.Controller.Controller;
import tp.p2.Game.Game;
import tp.p2.Zombie.ZombieFactory;

public class ZombieCommand extends NoParamsCommand{

	public ZombieCommand() {
		super("zombieList", "Z", "[Z]ombieList: print the list of available zombies.");
	}
 
	public void execute(Game game, Controller controller) {
			System.out.println(ZombieFactory.listOfAvilableZombies());
			controller.setNoPrintGameState();
	}

}