package tp.p2.Commands;

import tp.p2.Controller.Controller;
import tp.p2.Game.Game;
import tp.p2.Plants.PlantFactory;

public class ListCommand extends NoParamsCommand{

	public ListCommand() {
		super("list", "L", "[L]ist: print the list of available plants.");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute(Game game, Controller controller) {
		// TODO Auto-generated method stub
		System.out.println(PlantFactory.listOfAvilablePlants());
		controller.setNoPrintGameState();
	}

}
