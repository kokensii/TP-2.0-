package tp.p2.Commands;

import tp.p2.Controller.Controller;
import tp.p2.Game.Game;
import tp.p2.Plants.*;

public class AddCommand extends Command {

	private int x;
	private int y;
	private String planta;

	public AddCommand() {
		super("A", "add",
				"[A]dd <plant> <x> <y>: adds a plant in position x, y.");
		x = -1;
		y = -1;
		planta = null;
	}

	@Override
	public void execute(Game game, Controller controller) {
		Plant plant = PlantFactory.getPlant(planta);
		if (game.isEmpty(x, y)) {
			if (game.comprobarSuns(x, y, planta)) {
				game.addPlantToGame(plant, x, y);
				game.update();
			} else {
				System.out.println("No tienes soles suficientes");
			}
		}else{
			System.out.println("Esa posici�n est� ocupada");
		}
	}

	
	public Command parse(String[] commandWords, Controller controller) {
		if (commandWords.length != 4)
			return null;
		else {
			AddCommand salida = new AddCommand();

			salida.x = Integer.parseInt(commandWords[2]);
			if (salida.x >= 4) {
				System.out.println("Error en los comandos");
				return null;
			
			}
			salida.y = Integer.parseInt(commandWords[3]);
			if (salida.y >= 7) {
				System.out.println("Error en los comandos");
				return null;
			}
			
			salida.planta = commandWords[1];
			return salida;
		}
	}

}
