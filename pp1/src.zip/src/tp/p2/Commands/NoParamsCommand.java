package tp.p2.Commands;

import tp.p2.Controller.Controller;

public abstract class NoParamsCommand extends Command {

	public NoParamsCommand(String commandText, String commandTextMsg,
			String helpTextMsg) {
		super(commandText, commandTextMsg, helpTextMsg);
	}

	
	public Command parse(String[] commandWords, Controller controller) {
		Command c = null;
		if (commandWords[0].equalsIgnoreCase("")) commandWords[0] = "none";
		if (commandWords.length == 1
				&& (commandWords[0].equalsIgnoreCase(commandName)
				|| commandWords[0].equalsIgnoreCase(commandName.substring(0,1))))
			c = this;
		return c;
	}
}
