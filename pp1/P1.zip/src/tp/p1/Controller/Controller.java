package tp.p1.Controller;

import java.util.Scanner;

import tp.p1.Game.Game;

public class Controller {
	
	private Game game;
	private Scanner in;
	
	
	public Controller(Game game) {
		this.game = game;
		this.in = new Scanner(System.in);
	}
	
	public void run() { // solicitar ordenes al usuario y ejecutarlas
		String parts;
		String[] command;
		
		System.out.println(game.toString());
		boolean salir = true;
		game.toString();
		System.out.println("Command >");
		parts = this.in.nextLine();
		parts = parts.toUpperCase();
		command = parts.split(" ");
		
		do {			
			if(command[0].equals("HELP") || command[0].equals("H")) {
				System.out.println(game.help());
				System.out.println(game.toString());
			}
			else if(command[0].equals("LIST") || command[0].equals("L")) {
				System.out.println(game.list());
				System.out.println(game.toString());
			}
			else if (command[0].equals("ADD") || command[0].equals("A")) {
				if(command.length != 4) { 
					System.out.println("ERROR en el n�mero de comandos");
					}
				else{
					// Booleano que comprueba el tercer y cuarto comando para evitar una excepci�n en caso de introducir uno o varios caracteres no numericos
					boolean isdigit = true;
					for (char c : command[2].toCharArray()) {
						if(!Character.isDigit(c)) {
							isdigit = false;
						}
					} 
					if(isdigit == true) {
						for (char c : command[3].toCharArray()) {
							if(!Character.isDigit(c)) {
								isdigit = false;
							}
						} 
					}
					if(isdigit == true) { 
						int x = Integer.parseInt(command[2]);
						int y = Integer.parseInt(command[3]);
						String planta = command[1];
						if(game.isEmpty(x, y)){ //2
							if(x < 4 && y < 8) {
								if(planta.equalsIgnoreCase("sunflower") || planta.equalsIgnoreCase("s")) {
									if(game.comprobarSuns(x, y,planta)) {
										game.update();
									}
									else {
										System.out.println("Aviso: No tiene soles suficientes");
									}
								}
								else if(planta.equalsIgnoreCase("peashooter") || planta.equalsIgnoreCase("p")) {
									if(game.comprobarSuns(x, y,planta)) {
									game.update();
									}
									else {
										System.out.println("Aviso: No tiene soles suficientes");
									}
								}
								else {
										System.out.println("Error: tipo de planta no v�lido");
									}
								}
							
								else {
									System.out.println("Aviso: posicion fuera de rango");
								}
								System.out.println(game.toString());
						}
						else	{ 
							System.out.println("Aviso: la posici�n introducida ya se encuentra ocupada");
								}
					
				}
					else {
						System.out.println("Error de comando, la posici�n no es num�rica");
					}
				}
			}
			else if (command[0].equals("RESET") || command[0].equals("R")) {
				game.resetGame();
				//System.out.println(game.toString());
			}
			else if (command[0].length() == 0 ) { // NONE 
				game.update();
				System.out.println(game.toString());
			}
			else if (command[0].equals("EXIT") || command[0].equals("E")) {
				salir = false;
			}
			else System.out.println("Error de comando");
			
			if(!game.loseGame() && !game.winGame() && salir) {
				game.toString();
				System.out.println("Command >");
				parts = this.in.nextLine();
				parts = parts.toUpperCase();
				command = parts.split(" ");
			}
			else {
				if(game.loseGame()) {
					System.out.println("HAS PERDIDO LO SENTIMOS \n");
				}
				else if(game.winGame()) {
					System.out.println("HAS GANADO EL JUEGO!! \n");
				}
				else 
					System.out.println("HASTA LUEGO, GRACIAS POR JUGAR \n");
			}
		}while(!game.loseGame() && !game.winGame() && salir);
	}
}