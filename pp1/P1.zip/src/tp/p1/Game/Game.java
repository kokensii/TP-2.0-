package tp.p1.Game;

import java.util.Random;

import tp.p1.Manager.SuncoinManager;
import tp.p1.Manager.ZombieManager;
import tp.p1.Peashooter.Peashooter;
import tp.p1.Peashooter.PeashooterList;
import tp.p1.PlantsVsZombies.Level;
import tp.p1.Sunflower.Sunflower;
import tp.p1.Sunflower.SunflowerList;
import tp.p1.Zombie.Zombie;
import tp.p1.Zombie.ZombieList;

public class Game {
	
	static final int DIMX = 4;
	static final int DIMY = 8;
	static final int SUNFLOWER = 20;
	static final int PEASHOOTER = 50;
	
	private SunflowerList sunflowerList;
	private PeashooterList peashooterList;
	private ZombieList zombieList;
	private SuncoinManager managerSuns;
	private ZombieManager managerZombie;
	//private GamePrinter gp;
	private int contCycles;
	private Random aleatorio = new Random(System.currentTimeMillis());
	private Level level;
	
	public Game(Level level, Random rand) {
		this.level = level;
		this.contCycles = 0;
		initZombieList();
		initPeashooterList();
		initSunflowerList();
		initSuncoinManager();
		initZombieManager();
		//GamePrinter gp = new GamePrinter(this, DIMX, DIMY);
		this.aleatorio = rand;
	}
	
	public void update() {

		sunflowerList.update();
		peashooterList.update();
		zombieList.update();
		
		if(managerZombie.isZombieAdded()) {
			boolean added = false;
			do{
				int valorEntero = aleatorio.nextInt(4);
				if(isEmpty(valorEntero, 7)){
					Zombie z = new Zombie(valorEntero,7,this); //para que lo meta en la ultima fila 
					this.zombieList.add(z);
					added = true;
				}
			}while(!added);
		}
		
		this.contCycles++;
	}
	
	public int getContCycles() {
		return contCycles;
	}

	public void setContCycles(int contCycles) {
		this.contCycles = contCycles;
	}

	public Level getLevel() {
		return level;
	}

	public void setLevel(Level level) {
		this.level = level;
	}
	
	public String toString() {  // este metodo llamara al gameprinter para dibujar el tablero 
		String cadena = "";
		GamePrinter gp = new GamePrinter(this, 4, 8);
		if(this.contCycles == 0) cadena = "Random seed used: " + "2"/*poner seed*/ + "\n";
		cadena += "Number of cycles: " + this.contCycles + "\n" +
				  "Sun coins: " + this.managerSuns.getSunCoins() + "\n" +
				  "Remaining zombies: " + this.managerZombie.getNumZombies() + "\n" +
				  gp.toString();
		return cadena;
	}
	
	public boolean isEmpty(int x, int y) {
		if(!peashooterList.isPeashooter(x, y) && !sunflowerList.isSunflower(x, y) &&
			!zombieList.isZombie(x, y)) return true;
		return false;
	}
	
	public boolean isZombie(int x, int y) {//Comprobamos si en la posicion x, y se encuentra un zombie
		return zombieList.isZombie(x, y);
	}
	
	public boolean isPeashooter(int x, int y) {//Comprobamos si en la posicion x, y se encuentra un peashooter
		return peashooterList.isPeashooter(x, y);
	}
	
	public boolean isSunflower(int x, int y) {//Comprobamos si en la posicion x, y se encuentra un sunflower
		return sunflowerList.isSunflower(x, y);
	}
	
	private void initPeashooterList() {
		this.peashooterList = new PeashooterList();
	}
	
	private void initSunflowerList() {
		this.sunflowerList = new SunflowerList();
	}
	
	private void initZombieList() {
		this.zombieList = new ZombieList();
	}
	
	private void initSuncoinManager() {
		this.managerSuns = new SuncoinManager();
	}
	
	private void initZombieManager() {
		this.managerZombie = new ZombieManager(level, this.aleatorio);
	}
	
	public void restarVidaPeashooter(int x, int y, int dmg){
		peashooterList.restarVidaPeashooter(x, y, dmg);
	}
	
	public void restarVidaSunflower(int x, int y, int dmg){
		sunflowerList.restarVidaSunflower(x, y, dmg);
	}
	
	public void restarVidaZombie(int x, int y, int dmg){
		zombieList.restarVidaZombie(x, y, dmg);
	}
	
	public void sumarSoles(int suns){
		managerSuns.sumarSoles(suns);
	}
	
	public String drawBoard(int x, int y) {
			if(zombieList.isZombie(x,y))
				return zombieList.getZombie(zombieList.indexZombie(x, y)).toString();
			
			if(peashooterList.isPeashooter(x, y)) {
				return peashooterList.getPeashooter(peashooterList.indexPeashooter(x, y)).toString();
				}
			
			if(sunflowerList.isSunflower(x, y)) {
				return sunflowerList.getSunflower(sunflowerList.indexSunflower(x, y)).toString();
				}
			else {
				return " ";
			}
	}
	
	public boolean loseGame() {
		boolean fin = false;
		for(int i = 0; i < 4 && !fin ;i++) {
			if(isZombie(i,0)) {
				fin = true;
			}
		}
		return fin;
	}
	
	public boolean winGame() { 
		boolean fin = false;
		if(managerZombie.getNumZombies()== 0) {
			int numzombies = 0;
			for (int i = 0; i < DIMX; i++) {
				for(int j = 0; j < DIMY; j++) {
					if(isZombie(i, j)) {
						numzombies++;
					}
				}
			}
			fin = (numzombies == 0) ? true : false;
		}
		return fin;
	}
	
	public void resetGame() {
		initZombieList();
		initPeashooterList();
		initSunflowerList();
		initSuncoinManager();
		initZombieManager();
		this.contCycles = 0;
		//GamePrinter gp = new GamePrinter(this, 4, 8);
		System.out.println(toString());
	}
	
	public String help() {
		String cadenaHelp = "";
		cadenaHelp = "Add <plant> <x> <y>: Adds a plant in position x, y.\r\n" + 
				"List: Prints the list of available plants.\r\n" + 
				"Reset: Starts a new game.\r\n" +
				"Help: Prints this help message.\r\n" +
				"Exit: Terminates the program.\r\n" + 
				"[none]: Skips cycle.\r\n";
		return cadenaHelp;
	}
	
	public String list() {
		String cadenaList ="[S]unflower: Cost: 20 suncoins Harm: 0\r\n" + 
				"[P]eashooter: Cost: 50 suncoins Harm: 1";
		return cadenaList;
	}
	
	public boolean comprobarSuns(int x, int y, String planta) {
		boolean yes = false;
			if(planta.equalsIgnoreCase("sunflower") || planta.equalsIgnoreCase("s") && this.managerSuns.getSunCoins() >= SUNFLOWER){
				Sunflower s = new Sunflower(x,y,this);
				this.sunflowerList.add(s);
				this.managerSuns.restarSoles(SUNFLOWER);
				yes= true;
				}
			else if(planta.equalsIgnoreCase("peashooter") || planta.equalsIgnoreCase("p") && this.managerSuns.getSunCoins() >= PEASHOOTER){
				Peashooter p = new Peashooter(x, y, this);
				this.peashooterList.add(p);
				this.managerSuns.restarSoles(PEASHOOTER);
				yes= true;
		}
		return yes;
	}
}
