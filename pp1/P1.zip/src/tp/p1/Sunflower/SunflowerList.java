package tp.p1.Sunflower;

public class SunflowerList {
	
	static final int MAX = 32;
	
	private Sunflower sunflowerList[];
	private int cont;
	
	public SunflowerList() {
		sunflowerList = new Sunflower[MAX];
		cont = 0;
	}
	
	public void add(Sunflower s) {
		if(cont < MAX){
			sunflowerList[cont] = s;
			this.cont++;
		}
	}
	
	public void delete(int index) {
		for(int i = index; i < this.cont; ++i) this.sunflowerList[i] = this.sunflowerList[i + 1];
		this.cont--;
	}
	
	public void restarLife(int index, int dmg){
		sunflowerList[index].restarLife(dmg);
	}
	
	public int indexSunflower(int x, int y){
		int isP = -1;
		for(int i = 0; i < this.cont && isP == -1; ++i){
			if(sunflowerList[i].getX() == x && sunflowerList[i].getY() == y) isP = i;
		}
		return isP;
	}
	
	public void restarVidaSunflower(int x, int y, int dmg){
		int iS = indexSunflower(x, y);
		if(iS != -1) {
			this.restarLife(iS, dmg);
			if(sunflowerList[iS].getHp()== 0) {
				delete(iS);
			}
		}
	}
	
	public Sunflower getSunflower(int index){
		return sunflowerList[index];
	}
	
	public int getSize() {
		return this.cont;
	}
	
	public boolean isEmpty() {
		return this.cont == 0;
	}
	
	public boolean isSunflower(int x, int y) {
		boolean isS = false;
		int i = 0;
		while(i < cont && !isS){
			if(sunflowerList[i].getX() == x && sunflowerList[i].getY() == y) isS = true;
			i++;
		}
		return isS;
	}
	
	public void update(){
		for(int i = 0; i < this.cont; ++i){
			sunflowerList[i].update();
		}
	}

}
