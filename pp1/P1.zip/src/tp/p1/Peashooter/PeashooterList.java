package tp.p1.Peashooter;

public class PeashooterList {
	
	static final int MAX = 32;
	
	//private ArrayList<Peashooter> peashooterList;
	private Peashooter peashooterList[];
	private int cont;
	
	public PeashooterList() {
		peashooterList = new Peashooter[MAX];
		cont = 0;
	}
	
	public void add(Peashooter p) {
		if(cont < MAX){
			peashooterList[cont] = p;
			cont++;
		}
	}
	
	public void delete(int index) {
		for(int i = index; i < this.cont; ++i) this.peashooterList[i] = this.peashooterList[i + 1];
		this.cont--;
	}
	
	public int getSize() {
		return this.cont;
	}
	
	public boolean isEmpty() {
		return cont == 0;
	}
	
	public boolean isPeashooter(int x, int y) {
		boolean isP = false;
		int i = 0;
		while(i < cont && !isP){
			if(peashooterList[i].getX() == x && peashooterList[i].getY() == y) isP = true;
			i++;
		}
		return isP;
	}
	
	public void restarLife(int index, int dmg){
		peashooterList[index].restarLife(dmg);
	}
	
	public Peashooter getPeashooter(int index){
		return peashooterList[index];
	}
	
	public int indexPeashooter(int x, int y){
		int isP = -1;
		for(int i = 0; i < this.cont && isP == -1; ++i){
			if(peashooterList[i].getX() == x && peashooterList[i].getY() == y) isP = i;
		}
		return isP;
	}
	
	public void restarVidaPeashooter(int x, int y, int dmg){
		int iP = indexPeashooter(x, y);
		if(iP != -1) {
			this.restarLife(iP, dmg);
			if(peashooterList[iP].getHp()== 0) {
				delete(iP);
			}
		}
	}
	
	public void update(){
		for(int i = 0; i < this.cont; ++i){
			peashooterList[i].update();
		}
	}
	
}
